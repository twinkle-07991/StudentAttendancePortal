package user.event.aggregation.aggregation.constant;

public class RestConstant {

    public static final String BASE_URI_CO = "/api/v1";
    public static final String POST_EVENT = "/send/event";
    public static final String APPLICATION_JSON = "application/json";
    public static final String GET_REPORT = "/report";

}
