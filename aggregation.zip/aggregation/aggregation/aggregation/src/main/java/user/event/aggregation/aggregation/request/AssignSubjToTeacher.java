package user.event.aggregation.aggregation.request;

import lombok.Builder;
import lombok.Data;
import user.event.aggregation.aggregation.utils.SectionEnum;
import user.event.aggregation.aggregation.utils.SemesterEnum;
import user.event.aggregation.aggregation.utils.SubjectEnum;


@Data
@Builder
public class AssignSubjToTeacher {

    private int teacherId;

    private SemesterEnum semester;

    private SectionEnum section;

    private SubjectEnum subject;
}
