package user.event.aggregation.aggregation.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BaseResponse {

    public String status;
    public String message;
}
