package user.event.aggregation.aggregation.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SendEventResponse {

    private String status;
}
