package user.event.aggregation.aggregation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import user.event.aggregation.aggregation.model.*;
import user.event.aggregation.aggregation.repository.*;
import user.event.aggregation.aggregation.request.*;
import user.event.aggregation.aggregation.response.*;
import user.event.aggregation.aggregation.utils.*;
import user.event.aggregation.aggregation.service.UserService;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private LoginDataRepository loginDataRepository;
    @Autowired
    private TeacherRepository teacherRepository;
    @Autowired
    private StudentRepo studentRepo;
    @Autowired
    private AttendanceRepo attendanceRepo;
    @Autowired
    private TeacherSubjectMappingRepo teacherSubjectMappingRepo;

    @Override
    @Transactional
    public RegistrationResponse registerTeacher(RegisterTeacherRequest request) {

        Teacher teacher = Teacher.builder()
                .email(request.getEmail())
                .mobileNumber(request.getMobileNumber())
                .teacherName(request.getTeacherName())
                .build();
        teacher = teacherRepository.save(teacher);
        LoginData loginData = LoginData.builder()
                .username(request.getUsername())
                .password(request.getPassword())
                .userId(teacher.getTeacherId())
                .userType(UserTypeEnum.TEACHER.toString())
                .build();
        loginDataRepository.save(loginData);

        return RegistrationResponse.builder()
                .status("SUCCESS")
                .message("Registration Success!!!")
                .build();


    }

    @Override
    public LoginResponse userLogin(LoginRequest loginRequest) {

        LoginData loginData = loginDataRepository.findByUsernameAndPassword(loginRequest.getUsername(),loginRequest.getPassword());
        if(loginData!=null){
            return LoginResponse.builder()
                    .isLogin(true)
                    .message("Login success")
                    .status("SUCCESS")
                    .userType(UserTypeEnum.valueOf(loginData.getUserType()))
                    .build();
        }
        else {
            return LoginResponse.builder()
                    .isLogin(false)
                    .status("FAILED")
                    .message("Username and Password InCorrect!!")
                    .build();

        }
    }

    @Override
    @Transactional
    public RegistrationResponse registerStudent(RegisterStudentRequest request) {

        Student student = Student.builder()
                .section(request.getSection().toString())
                .address(request.getAddress())
                .mobileNumber(request.getMobileNumber())
                .email(request.getEmail())
                .branch(request.getBranch().toString())
                .course(request.getCourse().toString())
                .dob(getFormattedDate(request.getDob()))
                .fatherName(request.getFatherName())
                .gender(request.getGender().toString())
                .semester(request.getSemester().getSemesterId())
                .studentName(request.getStudentName())
                .build();

        student = studentRepo.save(student);
        String rollNumber = getRollNumber(student.getStudentId());
        student.setRollNumber(rollNumber);
        student = studentRepo.save(student);

        LoginData loginData = LoginData.builder()
                .username(request.getUsername())
                .password(request.getPassword())
                .userId(student.getStudentId())
                .userType(UserTypeEnum.STUDENT.toString())
                .build();
        loginDataRepository.save(loginData);

        return RegistrationResponse.builder()
                .status("SUCCESS")
                .message("Registration Success!!!")
                .rollNumber(student.getRollNumber())
                .build();

    }

    @Override
    @Transactional
    public BaseResponse markAttendance(AttendanceRequest attendanceRequest) {
        List<Attendance> attendanceList = new ArrayList<>();

        List<Student> students = studentRepo.findByCourseAndBranchAndSemesterAndSection(
                CourseEnum.MCA.toString(), BranchEnum.COMPUTER_APPLICATION.toString(),attendanceRequest.getSemester().getSemesterId(),attendanceRequest.getSection().toString());

        for(Student student : students){
            Attendance attendance = new Attendance();
            attendance.setAttendanceStatus(attendanceRequest.getPresentStudentRoll().contains(student.getRollNumber()));
            attendance.setRollNumber(student.getRollNumber());
            attendance.setDate(getFormattedDate(attendanceRequest.getDate()));
            attendance.setSubject(attendanceRequest.getSubject().toString());
            attendance.setTeacherName(attendanceRequest.getTeacherName());

            attendanceList.add(attendance);
        }
        attendanceRepo.saveAll(attendanceList);
        return BaseResponse.builder().message("Attendance Marking Success!!").status("SUCCESS").build();
    }

    @Override
    public ProfileResponse getProfile(String username) {

        LoginData loginData = loginDataRepository.findByUsername(username);
        if(UserTypeEnum.STUDENT.name().equals(loginData.getUserType())){
            return studentProfile(loginData.getUserId());
        }
        else {
            return teacherProfile(loginData.getUserId());
        }
    }

    @Override
    @Transactional
    public String assignSubjToTeacher(List<AssignSubjToTeacher> requests) {

        for(AssignSubjToTeacher request : requests) {
            if (!request.getSemester().getSubjects().contains(request.getSubject())) {
                return "Please provide Valid Subject and Semester!!";
            }
            TeacherSubjectMapping teacherSubjectMapping = TeacherSubjectMapping.builder()
                    .semesterId(request.getSemester().getSemesterId())
                    .subject(request.getSubject().name())
                    .teacherId(request.getTeacherId())
                    .section(request.getSection().name())
                    .build();
            teacherSubjectMappingRepo.save(teacherSubjectMapping);
        }
        return "SUCCESS";
    }

    @Override
    public SemesterList getSemesterByTeacherId(int teacherId) {

        List<TeacherSubjectMapping> teacherSubjectMappings = teacherSubjectMappingRepo.findByTeacherId(teacherId);
        Set<SemesterEnum> disSem = new HashSet<>();
        for(TeacherSubjectMapping req : teacherSubjectMappings){
            disSem.add(SemesterEnum.getSemesterBySemesterId(req.getSemesterId()));
        }
        return SemesterList.builder().semesters(disSem).teacherId(teacherId).build();
    }

    @Override
    public SectionList getSectionByTeacherIdAndSemester(int teacherId, SemesterEnum semester) {

        List<TeacherSubjectMapping> teacherSubjectMappings = teacherSubjectMappingRepo.findByTeacherIdAndSemesterId(teacherId,semester.getSemesterId());
        Set<SectionEnum> disSec = new HashSet<>();
        for(TeacherSubjectMapping req : teacherSubjectMappings){
            disSec.add(SectionEnum.valueOf(req.getSection()));
        }
        return SectionList.builder().sections(disSec).teacherId(teacherId).semester(semester).build();

    }

    @Override
    public SubjectList getSubjectByTeacherIdAndSemesterAndSection(int teacherId, SemesterEnum semester, SectionEnum section) {
        List<TeacherSubjectMapping> teacherSubjectMappings = teacherSubjectMappingRepo.findByTeacherIdAndSemesterIdAndSection(teacherId,semester.getSemesterId(),section.name());
        Set<SubjectEnum> disSubj = new HashSet<>();
        for(TeacherSubjectMapping req : teacherSubjectMappings){
            disSubj.add(SubjectEnum.valueOf(req.getSubject()));
        }
        return SubjectList.builder().subjects(disSubj).teacherId(teacherId).semester(semester).section(section).build();
    }

    @Override
    public StudentList getStudents(SemesterEnum semester, SectionEnum section) {

        List<Student> students = studentRepo.findBySemesterAndSection(semester.getSemesterId(), section.name());
        List<StudentReq> studentReqList = new ArrayList<>();
        for (Student student : students){
            StudentReq studentReq = new StudentReq();
            studentReq.setStudentName(student.getStudentName());
            studentReq.setRollNumber(student.getRollNumber());
            studentReqList.add(studentReq);
        }
        return StudentList.builder().students(studentReqList).section(section).semester(semester).build();

    }

    private ProfileResponse teacherProfile(int userId) {

        Teacher teacher = teacherRepository.findByTeacherId(userId);
        List<SemesterReq> semesterReqs = getTeacherHiercy(teacher);
        return ProfileResponse.builder()
                .userId(teacher.getTeacherId())
                .email(teacher.getEmail())
                .mobileNumber(teacher.getMobileNumber())
                .Name(teacher.getTeacherName())
                .semesters(semesterReqs)
                .build();
    }

    private List<SemesterReq> getTeacherHiercy(Teacher teacher) {

        List<SemesterReq> semesterReqs = new ArrayList<>();

        int semesterNo = 4;
        int sectionNo = 3;

        for(int i=1;i<=semesterNo;i++){
            SemesterReq semesterReq = new SemesterReq();
            List<SectionReq> sectionReqs = new ArrayList<>();
            int asc = 65;
            int semesterId = i;
            for(int j=1;j<=sectionNo;j++){
                SectionReq sectionReq = new SectionReq();
                List<SubjectReq> subjectReqs = new ArrayList<>();
                String sec = "SECTION_";
                sec = sec+(char)asc;
                asc++;
                List<TeacherSubjectMapping> teaSubMap = teacherSubjectMappingRepo.findByTeacherIdAndSemesterIdAndSection(teacher.getTeacherId(),semesterId,sec);

                if(!teaSubMap.isEmpty()){
                    for(TeacherSubjectMapping subjectMapping : teaSubMap){
                        SubjectReq subjectReq = new SubjectReq();
                        subjectReq.setSubject(subjectMapping.getSubject());
                        subjectReqs.add(subjectReq);
                    }
                }

                List<Student> studentList = studentRepo.findBySemesterAndSection(semesterId,sec);
                List<StudentReq> studentReqList = new ArrayList<>();
                for(Student student : studentList){
                    StudentReq studentReq = new StudentReq();
                    studentReq.setStudentName(student.getStudentName());
                    studentReq.setRollNumber(student.getRollNumber());
                    studentReqList.add(studentReq);
                }
                sectionReq.setSection(SectionEnum.valueOf(sec));
                sectionReq.setSubjects(subjectReqs);
                sectionReq.setStudents(studentReqList);
                sectionReqs.add(sectionReq);

            }
            semesterReq.setSemester(SemesterEnum.getSemesterBySemesterId(semesterId));
            semesterReq.setSections(sectionReqs);
            semesterReqs.add(semesterReq);

        }


        return semesterReqs;
    }

    private ProfileResponse studentProfile(int userId) {

        Student student = studentRepo.findByStudentId(userId);
        List<SubAndAttPer> subAndAttPerList = getSubjectPercentage(student);
        return ProfileResponse.builder()
                .Name(student.getStudentName())
                .mobileNumber(student.getMobileNumber())
                .email(student.getEmail())
                .address(student.getAddress())
                .branch(student.getBranch())
                .dob(student.getDob())
                .course(student.getCourse())
                .fatherName(student.getFatherName())
                .semester(student.getSemester())
                .gender(student.getGender())
                .rollNumber(student.getRollNumber())
                .section(student.getSection())
                .userId(student.getStudentId())
                .subAndAttPerList(subAndAttPerList)
                .build();

    }

    private List<SubAndAttPer> getSubjectPercentage(Student student) {

        List<SubAndAttPer> list = new ArrayList<>();
        List<SubjectEnum> subjectList = SemesterEnum.getSubjectBySemesterId(student.getSemester());
        for(SubjectEnum subj : subjectList){
            SubAndAttPer subAndAttPer = new SubAndAttPer();
            subAndAttPer.setSubject(subj);
            subAndAttPer.setPercentage(calculatePercentage(student,subj));
            list.add(subAndAttPer);
        }
        return list;
    }

    private float calculatePercentage(Student student, SubjectEnum subj) {

        List<Attendance> attendanceList = attendanceRepo.findByRollNumberAndSubject(student.getRollNumber(),subj.toString());
        float totalDays = attendanceList.size();
        float presentDays = (float) attendanceList.stream().filter(Attendance::isAttendanceStatus).count();
        return ((presentDays*100)/totalDays);
    }

    private String getFormattedDate(Date dob) {
        String pattern = "MM-dd-yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        return simpleDateFormat.format(dob);
    }

    private String getRollNumber(int studentId) {
        String[] str = {"0","0","0","0","0"};
        int length = str.length-1;
        while (studentId!=0){
            int mod = studentId%10;
            studentId = studentId/10;
            str[length]= String.valueOf(mod);
            length--;
        }
        String rollNumber = "ABES";
        for(int i=0;i<str.length;i++){
            rollNumber=rollNumber + str[i];
        }
        return rollNumber;
    }
}
