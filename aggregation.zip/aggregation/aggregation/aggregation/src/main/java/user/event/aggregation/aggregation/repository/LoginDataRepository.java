package user.event.aggregation.aggregation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import user.event.aggregation.aggregation.model.LoginData;

@Repository
public interface LoginDataRepository extends JpaRepository<LoginData, Integer> {
    LoginData findByUsernameAndPassword(String username, String password);

    LoginData findByUsername(String username);
}
