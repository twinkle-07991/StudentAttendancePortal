package user.event.aggregation.aggregation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.event.aggregation.aggregation.utils.BranchEnum;
import user.event.aggregation.aggregation.utils.CourseEnum;
import user.event.aggregation.aggregation.utils.SectionEnum;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.util.Date;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int studentId;

    @Column(unique = true)
    private String rollNumber;
    @Column
    private String studentName;
    @Column
    private String fatherName;
    @Column
    private String dob;
    @Column
    private String gender;
    @Column
    private String course;
    @Column
    private String branch;
    @Column
    private int semester;
    @Column
    private String section;
    @Column(unique = true)
    private String mobileNumber;
    @Column(unique = true)
    @Email
    private String email;
    @Column
    @Lob
    private String address;

}
