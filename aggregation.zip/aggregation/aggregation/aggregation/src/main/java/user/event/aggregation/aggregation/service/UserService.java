package user.event.aggregation.aggregation.service;

import user.event.aggregation.aggregation.request.*;
import user.event.aggregation.aggregation.response.*;
import user.event.aggregation.aggregation.utils.SectionEnum;
import user.event.aggregation.aggregation.utils.SemesterEnum;

import java.util.List;

public interface UserService {
    RegistrationResponse registerTeacher(RegisterTeacherRequest request);

    LoginResponse userLogin(LoginRequest loginRequest);

    RegistrationResponse registerStudent(RegisterStudentRequest request);

    BaseResponse markAttendance(AttendanceRequest attendanceRequest);

    ProfileResponse getProfile(String username);

    String assignSubjToTeacher(List<AssignSubjToTeacher> request);

    SemesterList getSemesterByTeacherId(int teacherId);

    SectionList getSectionByTeacherIdAndSemester(int teacherId, SemesterEnum semester);

    SubjectList getSubjectByTeacherIdAndSemesterAndSection(int teacherId, SemesterEnum semester, SectionEnum section);

    StudentList getStudents(SemesterEnum semester, SectionEnum section);
}
