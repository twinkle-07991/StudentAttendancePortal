const API_URL = Object.freeze({
    LOGIN_URL:'http://localhost:8082/user/login',
    GET_PROFILE:'http://localhost:8082/get/profile/'
});
$(document).ready(function() {
    var params = window.location.search;
    var getURLParams = function(params) {
        var hash;
        var json = {};
        var hashes = params.slice(params.indexOf('?') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            json[hash[0]] = hash[1];
        }
        return json;
    }

    params = getURLParams(params);
    var username = params.username;

    const url = API_URL.GET_PROFILE+username;
    console.log(url);
    fetch(url)
        .then(response => response.json())
        .then(result => {
        if(result!=null){
            document.querySelector(".studentName").innerHTML = result.name;
            document.querySelector(".rollNumber").innerHTML = result.rollNumber;
            document.querySelector(".branch").innerHTML = result.branch;
            document.querySelector(".section").innerHTML = result.section;


        }

    })
        .catch(error => {
        console.log("erorr occur")
        console.error('Error:', error);
    });

});