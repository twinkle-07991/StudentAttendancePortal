package user.event.aggregation.aggregation.utils;

public enum SubjectEnum {
    DSA_1,NETWORK_1,MATH_1,
    DSA_2,NETWORK_2,MATH_2,
    DSA_3,NETWORK_3,MATH_3,
    DSA_4,NETWORK_4,MATH_4;
}
