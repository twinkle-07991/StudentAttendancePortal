package user.event.aggregation.aggregation.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class ProfileResponse {

    private int userId;

    private String rollNumber;
    
    private String Name;
    
    private String fatherName;
    
    private String dob;
    
    private String gender;
    
    private String course;
    
    private String branch;
    
    private Integer semester;
    
    private String section;
    private String mobileNumber;

    private String email;

    private String address;

    List<SubAndAttPer> subAndAttPerList;
    List<SemesterReq> semesters;
}
