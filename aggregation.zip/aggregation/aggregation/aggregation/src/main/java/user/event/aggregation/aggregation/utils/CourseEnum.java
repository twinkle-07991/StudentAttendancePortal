package user.event.aggregation.aggregation.utils;

public enum CourseEnum {
    MCA;
}
