package user.event.aggregation.aggregation.request;

import jdk.jfr.Timestamp;
import lombok.Data;

@Data
public class SendEventRequest {

    private String userId;
    private String evenType;
    @Timestamp
    private Long timestamp;
}
