/*Constant and Enums*/
const UserType = Object.freeze({
    STUDENT:"STUDENT",
    TEACHER:"TEACHER"
});

const API_URL = Object.freeze({
    LOGIN_URL:'http://localhost:8082/user/login',
    GET_PROFILE:'http://localhost:8082/get/profile/'
});

const loginForm = document.getElementById("loginForm");
loginForm.addEventListener("submit", function (e) {
    e.preventDefault();
    console.log("inside event login addEventListener");
    login_button();
});
function login_button(){
    console.log("Activated with message:");
    const formData = new FormData(loginForm);
    console.log([...formData]);

    var object = {};
    formData.forEach(function(value, key){
        object[key] = value;
    });
    var payload = JSON.stringify(object);

    const url = API_URL.LOGIN_URL;
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            // Add any other headers as needed
        },
        body: payload,
    })
        .then(response => response.json())
        .then(result => {
        console.log('API Response:', result);
        if (result.login){
            console.log('Login Successful');

            console.log(result.userType)
            if(result.userType==UserType.TEACHER){
                window.location.href = "teacherHome.html";
            }
            else{
                redirectToStudentHomePage(payload);
            }


        }
        else{
            console.log(result.message);
            alert(result.message);
        }

    })
        .catch(error => {
        console.log("erorr occur")
        console.error('Error:', error);
    });

}

function redirectToStudentHomePage(payload){
    const myObj = JSON.parse(payload);
    var data = {
        username: myObj.username
    };
    window.location.href = "studentHome.html?"+ $.param(data);

}
