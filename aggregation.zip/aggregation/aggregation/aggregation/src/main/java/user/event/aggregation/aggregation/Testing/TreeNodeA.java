package user.event.aggregation.aggregation.Testing;

public class TreeNodeA {

    int val;
    TreeNodeA  left;
    TreeNodeA right;


}
