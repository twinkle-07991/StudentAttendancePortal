package user.event.aggregation.aggregation.Testing;

import java.util.Stack;

public class NextGreaterElement {

    public static void main(String[] args) {

        int [] arr = {3,10,4,2,1,2,6,1,7,2,9};
        int size = arr.length;
        Stack<Integer> stack = new Stack<>();
        int newArr[] = new int[size];


        for(int i=(2*size)-1;i>=0;i--){

            int index=i%size;
            int val = arr[index];
            if(stack.isEmpty()){
                newArr[index]=-1;
                stack.push(val);
                continue;
            }

            while (!stack.isEmpty() && stack.peek()<=val){
                stack.pop();
            }
            if(!stack.isEmpty() && stack.peek()>val){
                newArr[index]=stack.peek();
                stack.push(val);
            }
            else {
                newArr[index]=-1;
                stack.push(val);
                continue;

            }
        }

        for(int i=0;i<size;i++){
            System.out.print(newArr[i]+" ");
        }




    }
}
