package user.event.aggregation.aggregation.request;

import lombok.Data;

import javax.validation.constraints.Email;

@Data
public class RegisterTeacherRequest {

    private String teacherName;
    private String mobileNumber;
    @Email
    private String email;
    private String password;
    private String username;
}
