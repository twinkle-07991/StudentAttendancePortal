package user.event.aggregation.aggregation.response;

import lombok.Builder;
import lombok.Data;
import org.hibernate.usertype.UserType;
import user.event.aggregation.aggregation.utils.UserTypeEnum;

@Data
@Builder
public class LoginResponse {

    private String status;
    private boolean isLogin;
    private String message;
    private UserTypeEnum userType;

}
