package user.event.aggregation.aggregation.service.impl;

import org.springframework.stereotype.Service;
import user.event.aggregation.aggregation.request.SendEventRequest;
import user.event.aggregation.aggregation.response.ReportResponse;
import user.event.aggregation.aggregation.response.SendEventResponse;
import user.event.aggregation.aggregation.response.UserReportResponse;
import user.event.aggregation.aggregation.service.IUserAggregationService;
import user.event.aggregation.aggregation.utils.EventType;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserAggregationServiceImpl implements IUserAggregationService {

    //userId is main map key and date is the internal map key
    private Map<String, Map<String, ReportResponse>> globalMap = new HashMap<>();

    @Override
    public SendEventResponse sendEvent(List<SendEventRequest> sendEventRequest) {

        for (SendEventRequest request : sendEventRequest) {
            addEventInData(request);
        }
        return SendEventResponse.builder()
                .status("SUCCESS")
                .build();
    }

    @Override
    public List<UserReportResponse> getReport() {
        List<UserReportResponse> reportResponses = new ArrayList<>();
        for (Map<String, ReportResponse> reportResponseMap : globalMap.values()) {
            reportResponses.addAll(getReportModel(reportResponseMap.values()));
        }
        return reportResponses.stream()
                .sorted(Comparator.comparing(UserReportResponse::getDate)
                        .thenComparing(UserReportResponse::getUserId))
                .collect(Collectors.toList());
    }

    public List<UserReportResponse> getReportModel(Collection<ReportResponse> reportResponses) {
        List<UserReportResponse> userReportResponses = new ArrayList<>();
        for (ReportResponse response : reportResponses) {
            userReportResponses.add(UserReportResponse.builder()
                    .comment(response.getComment() != 0 ? String.valueOf(response.getComment()) : null)
                    .like(response.getLike() != 0 ? String.valueOf(response.getLike()) : null)
                    .userId(response.getUserId())
                    .post(response.getPost() != 0 ? String.valueOf(response.getPost()) : null)
                    .date(response.getDate()).build());
        }
        return userReportResponses;
    }


    private void addEventInData(SendEventRequest request) {
        String userId = request.getUserId();
        String date = dateFormat(request.getTimestamp());
        EventType evenType = EventType.getEventType(request.getEvenType());
        Map<String, ReportResponse> reportResponseMap = globalMap.containsKey(userId) ? globalMap.get(userId) : new HashMap<>();
        ReportResponse response = reportResponseMap.containsKey(date) ? reportResponseMap.get(date) : new ReportResponse();
        switch (evenType) {
            case POST:
                response.setPost(response.getPost() + 1);
                break;
            case COMMENT:
                response.setComment(response.getComment() + 1);
                break;
            case LIKE_RECEIVED:
                response.setLike(response.getLike() + 1);
                break;
            case INVALID:
                return;
        }
        response.setDate(date);
        response.setUserId(userId);
        reportResponseMap.put(date, response);
        globalMap.put(userId, reportResponseMap);
    }

    private String dateFormat(Long timestamp) {
        String pattern = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        return simpleDateFormat.format(timestamp);
    }
}
