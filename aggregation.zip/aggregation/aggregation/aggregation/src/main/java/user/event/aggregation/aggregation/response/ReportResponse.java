package user.event.aggregation.aggregation.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReportResponse {

    private String userId;
    private String date;
    private int post;
    private int comment;
    private int like;
}
