package user.event.aggregation.aggregation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import user.event.aggregation.aggregation.constant.RestConstant;
import user.event.aggregation.aggregation.request.SendEventRequest;
import user.event.aggregation.aggregation.response.SendEventResponse;
import user.event.aggregation.aggregation.response.UserReportResponse;
import user.event.aggregation.aggregation.service.IUserAggregationService;

import java.util.List;

import static user.event.aggregation.aggregation.constant.RestConstant.BASE_URI_CO;

@RestController
@RequestMapping(BASE_URI_CO)
public class UserAggregationController {


    @Autowired
    private IUserAggregationService iUserAggregationService;

    @RequestMapping(
            value = RestConstant.POST_EVENT,
            produces = RestConstant.APPLICATION_JSON,
            method = RequestMethod.POST)
    public SendEventResponse sendEvent(
            @RequestBody List<SendEventRequest> sendEventRequest) {
        return iUserAggregationService.sendEvent(sendEventRequest);
    }

    @RequestMapping(
            value = RestConstant.GET_REPORT,
            produces = RestConstant.APPLICATION_JSON,
            method = RequestMethod.GET)
    public List<UserReportResponse> getReport() {
        return iUserAggregationService.getReport();
    }

}
