package user.event.aggregation.aggregation.utils;

import lombok.Getter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Getter
public enum SemesterEnum {


    SEMESTER_1(1, "SEMESTER_1", Arrays.asList(SubjectEnum.MATH_1, SubjectEnum.DSA_1, SubjectEnum.NETWORK_1)),
    SEMESTER_2(2, "SEMESTER_2", Arrays.asList(SubjectEnum.MATH_2, SubjectEnum.DSA_2, SubjectEnum.NETWORK_2)),
    SEMESTER_3(3, "SEMESTER_3", Arrays.asList(SubjectEnum.MATH_3, SubjectEnum.DSA_3, SubjectEnum.NETWORK_3)),
    SEMESTER_4(4, "SEMESTER_4", Arrays.asList(SubjectEnum.MATH_4, SubjectEnum.DSA_4, SubjectEnum.NETWORK_4));


    int semesterId;
    String semester;
    List<SubjectEnum> subjects;

    SemesterEnum(int semesterId, String semester, List<SubjectEnum> asList) {
        this.semesterId = semesterId;
        this.semester = semester;
        this.subjects = asList;
    }

    public static List<SubjectEnum> getSubjectBySemesterId(int semesterId){

        switch (semesterId){
            case 1:return SEMESTER_1.getSubjects();
            case 2:return SEMESTER_2.getSubjects();
            case 3:return SEMESTER_3.getSubjects();
            case 4:return SEMESTER_4.getSubjects();
            default:return Collections.EMPTY_LIST;
        }

    }
    public static SemesterEnum getSemesterBySemesterId(int semesterId){
        switch (semesterId){
            case 1:return SEMESTER_1;
            case 2:return SEMESTER_2;
            case 3:return SEMESTER_3;
            case 4:return SEMESTER_4;
        }
        return null;
    }
}
