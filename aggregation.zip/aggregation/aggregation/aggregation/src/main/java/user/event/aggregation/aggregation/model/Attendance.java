package user.event.aggregation.aggregation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.event.aggregation.aggregation.utils.SubjectEnum;

import javax.persistence.*;
import java.util.Date;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(
        uniqueConstraints =
        @UniqueConstraint(columnNames = {"rollNumber", "date", "subject"})
)
public class Attendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column
    private String rollNumber;
    @Column
    private boolean attendanceStatus;
    @Column
    private String date;
    @Column
    private String subject;
    @Column
    private String teacherName;

}
