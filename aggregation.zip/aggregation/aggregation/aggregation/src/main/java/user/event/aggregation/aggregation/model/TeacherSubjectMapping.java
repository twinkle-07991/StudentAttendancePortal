package user.event.aggregation.aggregation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.event.aggregation.aggregation.utils.SectionEnum;
import user.event.aggregation.aggregation.utils.SubjectEnum;

import javax.persistence.*;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(
        uniqueConstraints=
                {@UniqueConstraint(columnNames = {"teacherId", "semesterId", "section", "subject"})}

)
public class TeacherSubjectMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column
    private int teacherId;

    @Column
    private int semesterId;

    @Column
    private String section;

    @Column
    private String  subject;
}
