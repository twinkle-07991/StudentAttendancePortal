package user.event.aggregation.aggregation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import user.event.aggregation.aggregation.model.Attendance;

import java.util.List;

@Repository
public interface AttendanceRepo extends JpaRepository<Attendance,Integer> {
    List<Attendance> findByRollNumberAndSubject(String rollNumber, String toString);
}
