package user.event.aggregation.aggregation.Testing;

public class KSubset {

    public static void main(String[] args) {
        int arr[] = {2,1,4,5,6};
        int k=3;
        int n = arr.length;
        System.out.println(isSubsetPossible(arr,k,n));
    }

    private static boolean isSubsetPossible(int[] arr, int k, int n) {

        if(k>n)
            return false;
        if(k==1)
            return true;
        int sum=0;
        for(int value : arr){
            sum+=value;
        }
        if(sum%k!=0)
            return false;


        boolean visited[] = new boolean[n];
        Boolean ans=false;
        int target = sum/k;
        int setCount = 0;
        int setCurrSum = 0;
        ans = solve(arr,n, k, setCurrSum, setCount, visited, target, ans);
        return ans;
    }

    private static boolean solve(int[] arr, int n, int k, int setCurrSum,
                              int setCount, boolean[] visited, int target, Boolean ans) {

        if(setCount==k-1){
            ans=true;
            return true;
        }
        if(setCurrSum>target)
        {
            return false;
        }
        if(setCurrSum==target){
            ans = solve(arr,n,k,0,setCount+1,visited,target,ans);
            if(ans)
                return true;
        }
        for(int i=0;i<n;i++){

            if(!visited[i]){
                visited[i]=true;
                ans = solve(arr,n,k,setCurrSum+arr[i],setCount,visited,target,ans);
                if(ans)
                    return true;

                visited[i]=false;
            }
        }
        return false;
    }
}
