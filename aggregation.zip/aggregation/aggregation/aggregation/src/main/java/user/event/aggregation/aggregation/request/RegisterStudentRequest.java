package user.event.aggregation.aggregation.request;

import lombok.Data;
import user.event.aggregation.aggregation.utils.*;

import javax.persistence.Lob;
import javax.validation.constraints.Email;
import java.util.Date;

@Data
public class RegisterStudentRequest {


    private String studentName;

    private String fatherName;

    private Date dob;

    private GenderEnum gender;

    private CourseEnum course;

    private BranchEnum branch;

    private SemesterEnum semester;

    private SectionEnum section;
    private String mobileNumber;
    @Email
    private String email;
    @Lob
    private String address;
    private String username;
    private String password;
}
