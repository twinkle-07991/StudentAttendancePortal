package user.event.aggregation.aggregation.service;

import user.event.aggregation.aggregation.request.SendEventRequest;
import user.event.aggregation.aggregation.response.SendEventResponse;
import user.event.aggregation.aggregation.response.UserReportResponse;

import java.util.List;

public interface IUserAggregationService {
    SendEventResponse sendEvent(List<SendEventRequest> sendEventRequest);

    List<UserReportResponse> getReport();
}
