package user.event.aggregation.aggregation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.event.aggregation.aggregation.utils.UserTypeEnum;

import javax.persistence.*;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(
        uniqueConstraints=
        @UniqueConstraint(columnNames={"userId", "userType"})
)
public class LoginData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int loginId;

    @Column(unique = true)
    private String username;
    @Column
    private String password;
    @Column
    private String userType;
    @Column
    private int userId;
}
