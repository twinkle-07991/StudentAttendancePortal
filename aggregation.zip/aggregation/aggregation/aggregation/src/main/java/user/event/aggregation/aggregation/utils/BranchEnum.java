package user.event.aggregation.aggregation.utils;

public enum BranchEnum {
    COMPUTER_APPLICATION;
}
