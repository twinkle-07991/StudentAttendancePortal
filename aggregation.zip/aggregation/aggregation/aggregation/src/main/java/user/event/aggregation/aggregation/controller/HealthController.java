package user.event.aggregation.aggregation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import user.event.aggregation.aggregation.request.*;
import user.event.aggregation.aggregation.response.*;
import user.event.aggregation.aggregation.service.UserService;
import user.event.aggregation.aggregation.utils.SectionEnum;
import user.event.aggregation.aggregation.utils.SemesterEnum;

import java.util.List;

@RestController
@CrossOrigin("*")
public class HealthController {

    @Autowired
    private UserService userService;



    @GetMapping("/health")
    public String healthCheck() {
        return "Server Up!!!";
    }

    @PostMapping("/register/teacher")
    public RegistrationResponse registerTeacher(@RequestBody RegisterTeacherRequest request){

        return userService.registerTeacher(request);
    }
    @PostMapping("/register/student")
    public RegistrationResponse registerStudent(@RequestBody RegisterStudentRequest request){
        return userService.registerStudent(request);

    }

    @PostMapping("/mark/attendance")
    public BaseResponse markAttendance(@RequestBody AttendanceRequest attendanceRequest){
        return userService.markAttendance(attendanceRequest);

    }

    @GetMapping("/get/profile/{username}")
    public ProfileResponse getProfile(@PathVariable String username){

        return userService.getProfile(username);
    }

    @PostMapping("/assign/class/toTeacher")
    public String assignSubjToTeacher(@RequestBody List<AssignSubjToTeacher> request){

        return userService.assignSubjToTeacher(request);
    }

    @GetMapping("/get/semester/{teacherId}")
    public SemesterList getSemesterByTeacherId(@PathVariable int teacherId){
        return userService.getSemesterByTeacherId(teacherId);

    }

    @GetMapping("/get/section/{teacherId}/{semester}")
    public SectionList getSectionByTeacherIdAndSemester(@PathVariable int teacherId, @PathVariable SemesterEnum semester){
        return userService.getSectionByTeacherIdAndSemester(teacherId,semester);

    }

    @GetMapping("/get/subject/{teacherId}/{semester}/{section}")
    public SubjectList getSubjectByTeacherIdAndSemesterAndSection(@PathVariable int teacherId, @PathVariable SemesterEnum semester, @PathVariable SectionEnum section){
        return userService.getSubjectByTeacherIdAndSemesterAndSection(teacherId,semester,section);

    }

    @GetMapping("/get/student/{semester}/{section}")
    public StudentList getStudents(@PathVariable SemesterEnum semester, @PathVariable SectionEnum section){
        return userService.getStudents(semester,section);

    }

    @PostMapping("/user/login")
    public LoginResponse userLogin(@RequestBody LoginRequest loginRequest){

        return userService.userLogin(loginRequest);

    }
}
