package user.event.aggregation.aggregation.utils;

public enum EventType {

    POST("post"),LIKE_RECEIVED("likeReceived"),COMMENT("comment"),INVALID("invalid");

    private String eventType;

    EventType(String eventType) {
        this.eventType=eventType;
    }

    public static EventType getEventType(String eventType){

        switch (eventType){
            case "post":
                return POST;
            case "likeReceived":
                return LIKE_RECEIVED;
            case "comment":
                return COMMENT;
        }
        return INVALID;

    }
}
