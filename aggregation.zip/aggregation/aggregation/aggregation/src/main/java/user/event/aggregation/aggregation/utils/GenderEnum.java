package user.event.aggregation.aggregation.utils;

public enum GenderEnum {

    MALE,FEMALE;
}
