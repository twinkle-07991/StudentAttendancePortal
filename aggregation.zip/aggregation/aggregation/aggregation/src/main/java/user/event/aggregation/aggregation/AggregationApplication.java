package user.event.aggregation.aggregation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import user.event.aggregation.aggregation.utils.SemesterEnum;

import java.util.Arrays;
import java.util.Random;
import java.util.stream.IntStream;

@SpringBootApplication
public class AggregationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AggregationApplication.class, args);
		System.out.println("User Event Aggregation Application!!!!");


	}

}
