package user.event.aggregation.aggregation.request;

import lombok.Builder;
import lombok.Data;
import user.event.aggregation.aggregation.utils.SectionEnum;
import user.event.aggregation.aggregation.utils.SemesterEnum;
import user.event.aggregation.aggregation.utils.SubjectEnum;

import java.util.Date;
import java.util.List;

@Data
@Builder
public class AttendanceRequest {

    private SemesterEnum semester;
    private SectionEnum section;
    private SubjectEnum subject;
    private String  teacherName;
    private Date date;
    List<String> presentStudentRoll;
}
