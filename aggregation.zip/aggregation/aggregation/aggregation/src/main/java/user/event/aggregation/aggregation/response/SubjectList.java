package user.event.aggregation.aggregation.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.event.aggregation.aggregation.utils.SectionEnum;
import user.event.aggregation.aggregation.utils.SemesterEnum;
import user.event.aggregation.aggregation.utils.SubjectEnum;

import java.util.Set;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class SubjectList {

    private int teacherId;
    private SemesterEnum semester;
    private SectionEnum section;
    private Set<SubjectEnum> subjects;
}
