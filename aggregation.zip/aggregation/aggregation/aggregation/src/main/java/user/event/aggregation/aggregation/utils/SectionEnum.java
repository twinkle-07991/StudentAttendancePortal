package user.event.aggregation.aggregation.utils;

public enum SectionEnum {
    SECTION_A,SECTION_B,SECTION_C;
}
