package user.event.aggregation.aggregation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import user.event.aggregation.aggregation.model.TeacherSubjectMapping;

import java.util.List;

@Repository
public interface TeacherSubjectMappingRepo extends JpaRepository<TeacherSubjectMapping,Integer> {
    List<TeacherSubjectMapping> findByTeacherId(int teacherId);

    List<TeacherSubjectMapping> findByTeacherIdAndSemesterIdAndSection(int teacherId, int semesterId, String name);

    List<TeacherSubjectMapping> findByTeacherIdAndSemesterId(int teacherId, int semesterId);
}
