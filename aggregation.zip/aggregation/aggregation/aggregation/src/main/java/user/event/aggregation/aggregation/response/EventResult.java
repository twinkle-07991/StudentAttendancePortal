package user.event.aggregation.aggregation.response;

import lombok.Data;

@Data
public class EventResult {
    private int comment;
    private int like;
    private int post;
}
