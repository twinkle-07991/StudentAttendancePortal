package user.event.aggregation.aggregation.Testing;

import java.util.*;
import java.util.stream.Collectors;
// 10,1,2,1,3,1,4,1,1,1,1,1 = 1,1,1,1,1,1,1,1,2,3,4,10
//0,1,2,3
//6,4,5,2 = sum=17,size=4/2=2
//1 sum=1,size=1/0 =
//[] sum=0,size=0
//0,1,2
//0,1,2
//0,1,2,3
//2,4,6,2 = 4/2=2

public class Solution {
    public static void main(String[] args) {

        List<Integer> list = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter size!!");
        int n = sc.nextInt();
        for(int i=0;i<n;i++) {
            int num= sc.nextInt();
            float median = addNumber(list, num);
            System.out.println("Median is = "+median);
        }

    }

    private static float addNumber(List<Integer> list, int num) {
        list.add(num);
        List<Integer> arr = list.stream().sorted().collect(Collectors.toList());
        int size =list.size();
        int sum = 0;
        for(Integer val : arr){
            sum+=val;
        }
        if(size==1)
            return list.get(0);
        if(size%2!=0){
            int index = size/2;
            return arr.get(index);
        }
        else {
            int index = size/2;
            int median = (arr.get(index)+arr.get(index-1))/2;
            return median;
        }

    }

}
