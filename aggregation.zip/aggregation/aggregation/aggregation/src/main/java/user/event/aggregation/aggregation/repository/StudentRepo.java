package user.event.aggregation.aggregation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import user.event.aggregation.aggregation.model.Student;
import user.event.aggregation.aggregation.utils.BranchEnum;
import user.event.aggregation.aggregation.utils.CourseEnum;
import user.event.aggregation.aggregation.utils.SectionEnum;

import java.util.List;

@Repository
public interface StudentRepo extends JpaRepository<Student,Integer> {
    List<Student> findByCourseAndBranchAndSemesterAndSection(String mca, String computerApplication, int semesterId, String section);

    Student findByStudentId(int userId);

    List<Student> findBySemesterAndSection(int semesterId, String sec);
}
