1. This is SpringBoot Application.
2. Main file is AggregationApplication.java
3. Run this file in any IDE that support tomcat,maven(intellij,eclipse)
4. Default on that application is running is 8080.
5. Health check url is - http://localhost:8080/health
6. send Event API that will record the evens in list format
    CURL:-
    curl --location --request POST 'http://localhost:8080/api/v1/send/event' \
    --header 'Content-Type: application/json' \
    --data-raw '[
        {
            "userId": 4,
            "evenType": "post",
            "timestamp": 1703310227650
        },
          {
            "userId": 3,
            "evenType": "likeReceived",
            "timestamp": 1703310227650
        }
    ]'

7. Get report API-
    CURL:-
    curl --location --request GET 'http://localhost:8080/api/v1/report'